(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[2705],{62590:function(e,r,n){Promise.resolve().then(n.bind(n,96250))},96250:function(e,r,n){"use strict";n.r(r);var t=n(9268);n(86006),r.default=function(){let e=()=>{};return(0,t.jsx)("div",{children:(0,t.jsx)("button",{onClick:()=>{e()},children:"测试"})})}},83177:function(e,r,n){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var t=n(86006),o=Symbol.for("react.element"),u=Symbol.for("react.fragment"),f=Object.prototype.hasOwnProperty,s=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,i={key:!0,ref:!0,__self:!0,__source:!0};function c(e,r,n){var t,u={},c=null,_=null;for(t in void 0!==n&&(c=""+n),void 0!==r.key&&(c=""+r.key),void 0!==r.ref&&(_=r.ref),r)f.call(r,t)&&!i.hasOwnProperty(t)&&(u[t]=r[t]);if(e&&e.defaultProps)for(t in r=e.defaultProps)void 0===u[t]&&(u[t]=r[t]);return{$$typeof:o,type:e,key:c,ref:_,props:u,_owner:s.current}}r.Fragment=u,r.jsx=c,r.jsxs=c},9268:function(e,r,n){"use strict";e.exports=n(83177)}},function(e){e.O(0,[9253,6488,1744],function(){return e(e.s=62590)}),_N_E=e.O()}]);